# GildedSky

Welcome to GildedSky

This is the workspace used to create GildedSky and is not the dowload for the mod.
Mod download is TBD but will be set up in the coming months.
